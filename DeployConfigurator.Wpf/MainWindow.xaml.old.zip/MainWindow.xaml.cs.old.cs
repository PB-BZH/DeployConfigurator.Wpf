using System.Diagnostics;
using System.Drawing.Printing;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using DeployConfigurator.Core.Services;
using DeployConfigurator.Wpf.Core.Builders;
using DeployConfigurator.Wpf.Core.Enums;
using DeployConfigurator.Wpf.Core.Models;
using DeployConfigurator.Wpf.Core.Pipeline;
using DeployConfigurator.Wpf.Core.Services;
using DeployConfigurator.Wpf.UI.Controls;
using DeployConfigurator.Wpf.UI.Helpers;
using Microsoft.Win32;
using PB.BZH.Help.Wpf.UI.Theming;
using PB.BZH.Licensing.Core.Services;

using Brushes = System.Windows.Media.Brushes;

namespace DeployConfigurator.Wpf;
/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow: Window {
  #region Fieldspublic MainForm() {
  private DeploymentProfile _profile = new();
  private List<PhysicalDiskInfo> _detectedDisks = [];

  private bool _livePreviewReady;
  private bool _isUpdatingPreview;
  private bool _isHighlighting;
  private bool _hasValidationError;

  private string _currentProfilePath = "";
  private string _fullPreviewText = "";

  private readonly HashSet<string> _collapsedSections = [];

  private PrintDocument? _printDocument;
  private string[] _printLines = [];
  private int _currentPrintLine;
  private CancellationTokenSource? _buildCancellation;

  private PreviewDocumentType _activePreviewDocument = PreviewDocumentType.Diskprep;
  private int _refreshCount;
  private bool _isRefreshingPreview;
  private readonly ManualResetEventSlim _pauseEvent = new(true);
  private bool _isPaused;
  private bool _pipelineHasWarning;
  private readonly Dictionary<string,RichTextBox> _previewEditors = [];
  private readonly Dictionary<RichTextBox,string> _editorFileNames = [];

  private bool _orchestrationPendingChanges;
  private readonly Dictionary<string,(int Start,int Span)>
  _pipelineProgressMap =
      new() {
        ["01"] = (0,5),
        ["02"] = (5,10),
        ["03"] = (15,25),
        ["04"] = (40,10),
        ["05"] = (50,15),
        ["06"] = (65,5),
        ["07"] = (70,5),
        ["08"] = (75,20),
        ["09"] = (95,3),
        ["10"] = (98,2),
      };
  private BuildPipelineService? _pipeline;
  private readonly List<PipelineStepLog> _pipelineSteps = [];
  private string _usbLiveReportPath = "";
  private readonly Lock _usbLiveReportLock = new();
  private int _currentStepProgressStart;
  private int _currentStepProgressSpan;

  private const string WebCategoryFolderName = "msi-software-packager";
  private readonly LicenseService _licenseService;
  private readonly PreviewSyntaxHighlighter _syntaxHighlighter = new();


  #endregion

  public MainWindow() {
    InitializeComponent();
    _licenseService = LicenseHelper.CreerLicenseService(_profile);

    ThemeMode.IsChecked = true;
    DarkTheme();

    #region UI Initialization

    LoadKeyboardLocales();
    PreviewKeyDown += MainForm_KeyDown;
    txtSearch.KeyDown += txtSearch_KeyDown;
    LoadDisks();
    LoadUsbDriveLetters();
    HookLivePreviewEvents();
    UpdateUiState();
    _livePreviewReady = true;
    ValidateConfiguration();
    RefreshPreview();
    UpdateStatusBar();
    picOperation.Source = LoadImageResource("gear.png");
    imgPauseResume.Source = LoadImageResource("ready.png");
    #endregion

  }

  private void MainForm_KeyDown(object? sender,KeyEventArgs e) {
    if (Keyboard.Modifiers.HasFlag(ModifierKeys.Control) && e.Key == Key.F) {
      txtSearch.Focus();
      txtSearch.SelectAll();
      e.Handled = true;
      return;
    }
    if (e.Key == Key.Escape) {
      txtSearch.Clear();
      CurrentPreviewTextBox.Focus();
      e.Handled = true;
    }
  }

  private void FindNext() {
    RichTextBox textBox = CurrentPreviewTextBox;
    string search = txtSearch.Text;
    if (string.IsNullOrWhiteSpace(search))
      return;
    string text = NormalizeRichText(GetRichText(textBox));
    int start = NormalizeRichText(new TextRange(textBox.Document.ContentStart,textBox.Selection.End).Text).Length;
    int index = text.IndexOf(search,start,StringComparison.OrdinalIgnoreCase);

    // Retour au début du document
    if (index < 0) {
      index = text.IndexOf(search,0,StringComparison.OrdinalIgnoreCase);
    }
    if (index < 0)
      return;
    TextPointer? selectionStart = GetTextPointerAtOffset(textBox,index);
    TextPointer? selectionEnd = GetTextPointerAtOffset(textBox,index + search.Length);
    if (selectionStart is null || selectionEnd is null) {
      return;
    }
    textBox.Selection.Select(selectionStart,selectionEnd);
    textBox.CaretPosition = selectionEnd;
    textBox.Focus();
    textBox.UpdateLayout();
    Rect position = selectionStart.GetCharacterRect(LogicalDirection.Forward);
    textBox.ScrollToVerticalOffset(Math.Max(0,textBox.VerticalOffset + position.Top - textBox.ViewportHeight / 2));
  }

  private static string NormalizeRichText(
  string text) {

    return text
      .Replace("\r\n","\n")
      .Replace('\r','\n');
  }

  private static TextPointer? GetTextPointerAtOffset(RichTextBox textBox,int offset) {
    TextPointer? pointer = textBox.Document.ContentStart.GetInsertionPosition(LogicalDirection.Forward);
    int currentOffset = 0;
    while (pointer is not null && currentOffset < offset) {
      TextPointer? next = pointer.GetNextInsertionPosition(LogicalDirection.Forward);
      if (next is null)
        break;
      pointer = next;
      currentOffset++;
    }
    return pointer;
  }


  private void txtSearch_KeyDown(object? sender,KeyEventArgs e) {
    if (e.Key == Key.Enter) {
      FindNext();
      e.Handled = true;
      return;
    }
    if (e.Key == Key.Escape) {
      txtSearch.Clear();
      CurrentPreviewTextBox.Focus();
      e.Handled = true;
    }
  }

  private void LoadUsbDriveLetters() {
    cmbUsbDriveLetter.Items.Clear();

    List<UsbDeviceInfo> devices =
        UsbPreparationService.DetectUsbDevices();

    foreach (UsbDeviceInfo device in devices) {
      cmbUsbDriveLetter.Items.Add(device);
    }

    if (cmbUsbDriveLetter.Items.Count > 0)
      cmbUsbDriveLetter.SelectedIndex = 0;
  }

  private readonly List<KeyboardLocaleOption> _keyboardLocales = [
  new KeyboardLocaleOption
    {
        DisplayName = "Français France - fr-FR",
        LanguageTag = "fr-FR",
        InputLocaleCode = "040c:0000040c"
    },
    new KeyboardLocaleOption
    {
        DisplayName = "Anglais US - en-US",
        LanguageTag = "en-US",
        InputLocaleCode = "0409:00000409"
    },
    new KeyboardLocaleOption
    {
        DisplayName = "Allemand Allemagne - de-DE",
        LanguageTag = "de-DE",
        InputLocaleCode = "0407:00000407"
    },
    new KeyboardLocaleOption
    {
        DisplayName = "Espagnol Espagne - es-ES",
        LanguageTag = "es-ES",
        InputLocaleCode = "0c0a:0000040a"
    }
];


  private void LoadKeyboardLocales() {
    lstInputLocales.Items.Clear();

    foreach (var locale in _keyboardLocales)
      lstInputLocales.Items.Add(locale);
  }


  private void LoadDisks() {
    _detectedDisks = DiskDetectionService.GetDisks();

    cmbOsDisk.ItemsSource = new List<PhysicalDiskInfo>(_detectedDisks);
    cmbData1Disk.ItemsSource = new List<PhysicalDiskInfo>(_detectedDisks);
    cmbData2Disk.ItemsSource = new List<PhysicalDiskInfo>(_detectedDisks);
  }


  private void HookConfigurationChanged(
  CheckBox checkBox) {

    checkBox.Checked +=
      ConfigurationChanged;

    checkBox.Unchecked +=
      ConfigurationChanged;
  }

  private void MarkOrchestrationPending() {
    _orchestrationPendingChanges = true;

    lblOrchestrationPending.Content = "\u25CF Changes pending use [ Apply All ] to apply";
    lblOrchestrationPending.Foreground = Brushes.Orange;
    lblOrchestrationPending.Background = Brushes.Transparent;
    lblOrchestrationPending.Visibility = Visibility.Visible;
    lblOrchestrationPending.FontFamily = new System.Windows.Media.FontFamily("Segoe UI");
    lblOrchestrationPending.FontSize = 8.5;
    lblOrchestrationPending.FontWeight = FontWeights.Bold;
  }

  private void HookOrchestrationPending(CheckBox checkBox) {
    checkBox.Checked += (_,_) => MarkOrchestrationPending();
    checkBox.Unchecked += (_,_) => MarkOrchestrationPending();
  }

  private void HookLivePreviewEvents() {

    // ============================================================
    // STORAGE
    // ============================================================

    HookConfigurationChanged(chkSeparateDataDisk);
    HookConfigurationChanged(chkCreateData1);
    HookConfigurationChanged(chkCreateData2);

    cmbOsDisk.SelectionChanged += ConfigurationChanged;
    cmbData1Disk.SelectionChanged += ConfigurationChanged;
    cmbData2Disk.SelectionChanged += ConfigurationChanged;
    cmbImageType.SelectionChanged += ConfigurationChanged;

    // ============================================================
    // AUTOUNATTEND / UNATTEND
    // ============================================================

    cmbUiLanguage.SelectionChanged += ConfigurationChanged;
    cmbTimeZone.SelectionChanged += ConfigurationChanged;
    HookDeferredRefresh(txtOrganization);
    HookDeferredRefresh(txtOwner);
    numEfiSize.ValueChanged += ConfigurationChanged;
    numMsrSize.ValueChanged += ConfigurationChanged;
    numSystemBiosSize.ValueChanged += ConfigurationChanged;
    numWindowsSize.ValueChanged += ConfigurationChanged;
    numRecoverySize.ValueChanged += ConfigurationChanged;
    numImageIndex.ValueChanged += ConfigurationChanged;
    HookConfigurationChanged(chkCreateLocalAccount);
    cmbLocalUserGroup.SelectionChanged += ConfigurationChanged;
    HookConfigurationChanged(chkEnableAutoLogon);
    numAutoLogonCount.ValueChanged += ConfigurationChanged;
    HookDeferredRefresh(txtProductKey);
    HookDeferredRefresh(txtLocalUserName);
    HookDeferredRefresh(txtComputerName);


    // PasswordBox : ce n'est pas un TextBox
    txtAdminPassword.PasswordChanged += ConfigurationChanged;

    // ============================================================
    // PACKAGE
    // ============================================================

    HookConfigurationChanged(chkIncludeDrivers);
    HookConfigurationChanged(chkIncludeApplications);
    HookConfigurationChanged(chkIncludeScripts);
    HookConfigurationChanged(chkIncludeWinPE);
    HookConfigurationChanged(chkIncludeSetupScripts);
    HookConfigurationChanged(chkIncludeSetupConfig);
    HookDeferredRefresh(txtSetupScriptsSourcePath);
    HookDeferredRefresh(txtSetupConfigSourcePath);
    HookDeferredRefresh(txtPackageName);
    HookDeferredRefresh(txtPackageVersion);
    HookDeferredRefresh(txtPackageAuthor);
    HookDeferredRefresh(txtOutputDirectory);
    HookDeferredRefresh(txtDriversSourcePath);
    HookDeferredRefresh(txtApplicationsSourcePath);

    // ============================================================
    // POST-INSTALL ORCHESTRATION
    // ============================================================

    HookOrchestrationPending(chkRunDetachUsb);
    HookOrchestrationPending(chkRunReorgVolumes);
    HookOrchestrationPending(chkRunWifi);
    HookOrchestrationPending(chkRunDrivers);
    HookOrchestrationPending(chkRunWindowsUpdateDrivers);
    HookOrchestrationPending(chkRunSoftwares);
    HookOrchestrationPending(chkRunM365);
    HookOrchestrationPending(chkRunPostInstall);
    HookOrchestrationPending(chkRunCleanup);
  }
  private static BitmapImage LoadImageResource(string fileName) {
    return new BitmapImage(new Uri($"/Ressources/{fileName}",UriKind.Relative));
  }

  private void HookDeferredRefresh(
    Control control) {

    if (control is TextBox txt) {

      txt.KeyDown +=
        DeferredRefresh_KeyDown;

      txt.LostKeyboardFocus +=
        DeferredRefresh_LostKeyboardFocus;
    }

    else if (control is CheckBox chk) {

      chk.LostKeyboardFocus +=
        DeferredRefresh_LostKeyboardFocus;

      chk.KeyDown +=
        (s,e) => {

          if (e.Key == Key.Enter) {

            e.Handled = true;

            ConfigurationChanged(
              s,
              e);
          }
        };
    }

    else if (control is ComboBox cmb) {

      cmb.SelectionChanged +=
        ConfigurationChanged;
    }

    else if (control is NumericUpDown num) {

      num.ValueChanged +=
        ConfigurationChanged;
    }
  }

  private void DeferredRefresh_KeyDown(
  object sender,
  KeyEventArgs e) {

    if (e.Key != Key.Enter)
      return;

    e.Handled = true;

    ConfigurationChanged(
      sender,
      e);
  }

  private void DeferredRefresh_LostKeyboardFocus(
  object sender,
  KeyboardFocusChangedEventArgs e) {

    ConfigurationChanged(
      sender,
      e);
  }

  private void TestDiskPrepPreview() {

    string test =
      """
    @echo off
    :: Test du fichier diskprep.cmd

    echo Préparation du disque...
    set DISK=0

    if "%DISK%"=="0" goto PREPARE

    :PREPARE
    diskpart /s diskpart.txt

    echo Installation de l'image
    dism /Apply-Image /ImageFile:install.wim /Index:1 /ApplyDir:C:\

    bcdboot C:\Windows

    echo SUCCESS
    echo WARNING : ceci est un test
    echo ERROR : erreur simulée

    set RC=3010
    echo RC=%RC%
    echo ERRORLEVEL=%ERRORLEVEL%

    exit /b 0
    """;

    SetRichText(
      previewDiskPrep.Editor,
      test);

    _syntaxHighlighter.ApplyCmd(
      previewDiskPrep.Editor);
  }

  private void mnuThemeSombre_click(object sender,RoutedEventArgs e) {
    DarkTheme();
  }

  private void ApplyUiToProfile() {
    if (cmbOsDisk.SelectedItem is PhysicalDiskInfo osDisk)
      _profile.Disk.OsDisk = osDisk.DiskNumber;

    _profile.Disk.DataDisk =
        chkSeparateDataDisk.IsChecked == true && cmbData1Disk.SelectedItem is PhysicalDiskInfo dataDisk
            ? dataDisk.DiskNumber
            : null;

    _profile.Disk.Data2Disk =
        chkCreateData2.IsChecked == true && cmbData2Disk.SelectedItem is PhysicalDiskInfo data2Disk
            ? data2Disk.DiskNumber
            : null;

    _profile.Disk.CreateData1 = chkCreateData1.IsChecked == true;
    _profile.Disk.CreateData2 = chkCreateData2.IsChecked == true;

    if (chkCreateData2.IsChecked == true)
      _profile.Disk.LayoutMode = DiskLayoutMode.DualDataDisk;
    else if (chkSeparateDataDisk.IsChecked == true)
      _profile.Disk.LayoutMode = DiskLayoutMode.SeparateDataDisk;
    else
      _profile.Disk.LayoutMode = DiskLayoutMode.SingleDisk;

    _profile.Disk.EfiSizeMb = (int)numEfiSize.Value;
    _profile.Disk.MsrSizeMb = (int)numMsrSize.Value;
    _profile.Disk.SystemSizeMb = (int)numSystemBiosSize.Value;
    _profile.Disk.WindowsSizeMb = (int)numWindowsSize.Value;
    _profile.Disk.RecoverySizeMb = (int)numRecoverySize.Value;
    _profile.Disk.FirmwareMode = FirmwareMode.Auto;

    _profile.Unattend.CreateLocalAccount = chkCreateLocalAccount.IsChecked == true;
    _profile.Unattend.LocalUserName = txtLocalUserName.Text;
    _profile.Unattend.LocalUserPassword = txtAdminPassword.Password;

    _profile.Unattend.LocalUserGroup = cmbLocalUserGroup.SelectedItem?.ToString() ?? "Administrators";
    _profile.Unattend.ComputerName = string.IsNullOrWhiteSpace(txtComputerName.Text) ? "*" : txtComputerName.Text;
    _profile.Unattend.EnableAutoLogon = chkEnableAutoLogon.IsChecked == true;
    _profile.Unattend.AutoLogonCount = (int)numAutoLogonCount.Value;
    _profile.Unattend.UILanguageFallback = _profile.Unattend.UILanguage;

    var selectedLocales = lstInputLocales.SelectedItems
    .Cast<KeyboardLocaleOption>()
    .ToList();

    _profile.Unattend.InputLocale = string.Join(";",selectedLocales.Select(x => x.InputLocaleCode));
    _profile.Unattend.SystemLocale = string.Join(";",selectedLocales.Select(x => x.LanguageTag));
    _profile.Unattend.UILanguage = cmbUiLanguage.SelectedItem?.ToString() ?? "fr-FR";
    _profile.Unattend.UserLocale = _profile.Unattend.UILanguage;
    _profile.Unattend.UILanguageFallback = _profile.Unattend.UILanguage;

    _profile.Image.ImageType = cmbImageType.SelectedIndex switch {
      1 => WindowsImageType.Wim,
      2 => WindowsImageType.Esd,
      _ => WindowsImageType.Auto
    };

    _profile.Image.InstallImage = cmbImageType.SelectedIndex switch {
      1 => "install.wim",
      2 => "install.esd",
      _ => "auto"
    };

    _profile.Image.ImageIndex = (int)numImageIndex.Value;

    _profile.Unattend.ProductKey = txtProductKey.Text;

    _profile.Unattend.UILanguage = cmbUiLanguage.SelectedItem?.ToString() ?? "fr-FR";

    _profile.Unattend.UserLocale = cmbUiLanguage.SelectedItem?.ToString() ?? "fr-FR";

    _profile.Unattend.TimeZone = cmbTimeZone.SelectedItem?.ToString() ?? "Romance Standard Time";

    _profile.Unattend.Organization = txtOrganization.Text;
    _profile.Unattend.Owner = txtOwner.Text;

    _profile.Unattend.CreateLocalAccount = chkCreateLocalAccount.IsChecked == true;
    _profile.Unattend.LocalUserName = txtLocalUserName.Text;
    _profile.Unattend.LocalUserPassword = txtAdminPassword.Password;
    _profile.Unattend.LocalUserGroup = cmbLocalUserGroup.SelectedItem?.ToString() ?? "Administrators";

    _profile.Unattend.EnableAutoLogon = chkEnableAutoLogon.IsChecked == true;
    _profile.Unattend.AutoLogonCount = (int)numAutoLogonCount.Value;

    _profile.Unattend.InputLocaleCodes = [.. lstInputLocales.SelectedItems
      .Cast<KeyboardLocaleOption>()
      .Select(static x => x.InputLocaleCode)];

    _profile.Unattend.InputLocale = string.Join(";",_profile.Unattend.InputLocaleCodes);

    _profile.Unattend.UILanguage = cmbUiLanguage.SelectedItem?.ToString() ?? "fr-FR";

    _profile.Unattend.UserLocale = _profile.Unattend.UILanguage;

    _profile.Unattend.UILanguageFallback = _profile.Unattend.UILanguage;

    _profile.Package.PackageName = txtPackageName.Text;
    _profile.Package.Version = txtPackageVersion.Text;
    _profile.Package.Author = txtPackageAuthor.Text;
    _profile.Package.OutputDirectory = txtOutputDirectory.Text;

    _profile.Package.IncludeDrivers = chkIncludeDrivers.IsChecked == true;
    _profile.Package.IncludeApplications = chkIncludeApplications.IsChecked == true;
    _profile.Package.IncludeScripts = chkIncludeScripts.IsChecked == true;
    _profile.Package.IncludeWinPE = chkIncludeWinPE.IsChecked == true;

    _profile.Package.DriversSourcePath = txtDriversSourcePath.Text;
    _profile.Package.ApplicationsSourcePath = txtApplicationsSourcePath.Text;
    //_profile.Package.ScriptsSourcePath = txtScriptsSourcePath.Text;
    //_profile.Package.WinPESourcePath = txtWinPESourcePath.Text;
    _profile.Package.IncludeSetupScripts = chkIncludeSetupScripts.IsChecked == true;
    _profile.Package.IncludeSetupConfig = chkIncludeSetupConfig.IsChecked == true;
    _profile.Package.SetupScriptsSourcePath = txtSetupScriptsSourcePath.Text;
    _profile.Package.SetupConfigSourcePath = txtSetupConfigSourcePath.Text;

    _profile.Package.IncludeSetupScripts = chkIncludeSetupScripts.IsChecked == true;
    _profile.Package.IncludeSetupConfig = chkIncludeSetupConfig.IsChecked == true;

    _profile.Package.SetupScriptsSourcePath = txtSetupScriptsSourcePath.Text;
    _profile.Package.SetupConfigSourcePath = txtSetupConfigSourcePath.Text;

    _profile.WindowsMedia.WindowsIsoPath = txtWindowsIsoPath.Text;
    _profile.WindowsMedia.MediaFolder = txtMediaWorkingDirectory.Text;
    _profile.WindowsMedia.ExtractWindowsIso = chkExtractWindowsIso.IsChecked == true;
    _profile.WindowsMedia.InjectAutounattend = chkInjectAutounattend.IsChecked == true;
    _profile.WindowsMedia.InjectDeployFolder = chkInjectDeployFolder.IsChecked == true;
    _profile.WindowsMedia.PrepareUsbMedia = chkPrepareUsbMedia.IsChecked == true;
    if (cmbUsbDriveLetter.SelectedItem is UsbDeviceInfo usb) {
      _profile.WindowsMedia.UsbDriveLetter = usb.DriveLetters;
    }
    else {
      _profile.WindowsMedia.UsbDriveLetter = cmbUsbDriveLetter.Text;
    }
    _profile.WindowsMedia.BuildIso = chkBuildIso.IsChecked == true;
    _profile.WindowsMedia.IsoOutputPath = txtFinalIsoPath.Text;

    _profile.Orchestration.RunDetachUsb = chkRunDetachUsb.IsChecked == true;
    _profile.Orchestration.RunReorgVolumes = chkRunReorgVolumes.IsChecked == true;
    _profile.Orchestration.RunWifi = chkRunWifi.IsChecked == true;
    _profile.Orchestration.RunDrivers = chkRunDrivers.IsChecked == true;
    _profile.Orchestration.RunWindowsUpdateDrivers = chkRunWindowsUpdateDrivers.IsChecked == true;
    _profile.Orchestration.RunSoftwares = chkRunSoftwares.IsChecked == true;
    _profile.Orchestration.RunMicrosoft365 = chkRunM365.IsChecked == true;
    _profile.Orchestration.RunPostInstall = chkRunPostInstall.IsChecked == true;
    _profile.Orchestration.RunCleanup = chkRunCleanup.IsChecked == true;
  }

  private static void SelectComboValue(ComboBox comboBox,string value) {
    for (int i = 0;i < comboBox.Items.Count;i++) {
      string? itemValue = comboBox.Items[i] switch {
        ComboBoxItem item => item.Content?.ToString(),
        _ => comboBox.Items[i]?.ToString()
      };
      if (string.Equals(itemValue,value,StringComparison.OrdinalIgnoreCase)) {
        comboBox.SelectedIndex = i;
        return;
      }
    }
    if (comboBox.Items.Count > 0) {
      comboBox.SelectedIndex = 0;
    }
  }

  private void ConfigurationChanged(object? sender,RoutedEventArgs e) {
    Debug.WriteLine($"CONFIG CHANGE from: {(sender as Control)?.Name}");
    if (!_livePreviewReady)
      return;

    if (_isRefreshingPreview)
      return;

    try {
      _isRefreshingPreview = true;

      UpdateUiState();
      ValidateConfiguration();
      RefreshPreview();
      UpdateStatusBar();
    }
    finally {
      _isRefreshingPreview = false;
    }
  }

  private string GeneratePreviewDocument(PreviewDocumentType documentType) {
    string templatesRoot = Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Templates");

    if (documentType == PreviewDocumentType.BuildReport)
      return GenerateBuildReport();

    return PreviewDocumentBuilder.Generate(documentType,_profile,templatesRoot);
  }

  private static void AppendResourceStatus(StringBuilder sb,string name,bool enabled,string path) {
    if (!enabled) {
      sb.AppendLine($"[DISABLED] {name}");
      return;
    }

    if (string.IsNullOrWhiteSpace(path)) {
      sb.AppendLine($"[WARNING] {name} path empty");
      return;
    }

    if (!Directory.Exists(path)) {
      sb.AppendLine($"[ERROR] {name} path not found");
      return;
    }

    int files = Directory.GetFiles(
        path,
        "*",
        SearchOption.AllDirectories
    ).Length;

    sb.AppendLine($"[OK] {name}");
    sb.AppendLine($"     Path  : {path}");
    sb.AppendLine($"     Files : {files}");
  }

  private string GenerateBuildReport() {
    StringBuilder sb = new();

    sb.AppendLine("=== DEPLOY PACKAGE REPORT ===");
    sb.AppendLine();

    sb.AppendLine($"Package Name .......... {_profile.Package.PackageName}");
    sb.AppendLine($"Version ............... {_profile.Package.Version}");
    sb.AppendLine($"Author ................ {_profile.Package.Author}");
    sb.AppendLine();

    sb.AppendLine($"Output Directory ...... {_profile.Package.OutputDirectory}");
    sb.AppendLine();

    sb.AppendLine("=== INCLUDED RESOURCES ===");
    sb.AppendLine();

    AppendResourceStatus(
        sb,
        "Drivers",
        _profile.Package.IncludeDrivers,
        _profile.Package.DriversSourcePath
    );

    AppendResourceStatus(
        sb,
        "Applications",
        _profile.Package.IncludeApplications,
        _profile.Package.ApplicationsSourcePath
    );

    AppendResourceStatus(
        sb,
        "Setup Scripts",
        _profile.Package.IncludeSetupScripts,
        _profile.Package.SetupScriptsSourcePath
    );

    AppendResourceStatus(
        sb,
        "Setup Config",
        _profile.Package.IncludeSetupConfig,
        _profile.Package.SetupConfigSourcePath
    );

    AppendResourceStatus(
        sb,
        "WinPE",
        _profile.Package.IncludeWinPE,
        _profile.Package.WinPESourcePath
    );

    sb.AppendLine();
    sb.AppendLine("=== VALIDATION ===");
    sb.AppendLine();

    sb.AppendLine(
        string.IsNullOrWhiteSpace(_profile.Unattend.ProductKey)
            ? "[WARNING] Product Key empty"
            : "[OK] Product Key"
    );

    sb.AppendLine(
        string.IsNullOrWhiteSpace(_profile.Unattend.LocalUserPassword)
            ? "[WARNING] Local user password empty"
            : "[OK] Local user password"
    );
    sb.AppendLine();
    sb.AppendLine("=== PRE-BUILD VALIDATION ===");
    sb.AppendLine();

    BuildValidationService validation = new();

    List<ValidationIssue> issues = BuildValidationService.Validate(_profile);

    if (issues.Count == 0) {
      sb.AppendLine(
          "[OK] No validation issue detected."
      );
    }
    else {
      foreach (var group in issues.GroupBy(x => x.Category)) {
        sb.AppendLine($"--- {group.Key} ---");

        foreach (ValidationIssue issue in group) {
          sb.AppendLine(
              $"[{issue.Severity}] {issue.Message}"
          );
        }

        sb.AppendLine();
      }
    }
    sb.AppendLine();
    sb.AppendLine("=== BUILD STATUS ===");

    bool hasError =
        issues.Any(x => x.Severity == "ERROR");

    if (hasError) {
      sb.AppendLine(
          "[BLOCKED] Build cannot start."
      );
    }
    else {
      sb.AppendLine(
          "[READY] Build can start."
      );
    }

    return sb.ToString();
  }

  private RichTextBox CurrentPreviewTextBox => _activePreviewDocument switch {
    PreviewDocumentType.AutoUnattend => previewAutoUnattend.Editor,
    PreviewDocumentType.Unattend => previewUnattend.Editor,
    PreviewDocumentType.SetupComplete => previewSetupComplete.Editor,
    PreviewDocumentType.ProfileJson => previewProfileDeployJson.Editor,
    PreviewDocumentType.BuildReport => previewprofileBuildReport.Editor,
    PreviewDocumentType.Orchestrator => previewOrchestrator_resume.Editor,
    _ => previewDiskPrep.Editor
  };

  [GeneratedRegex(@"^\d{1,3}%")]
  private static partial Regex PercentRegex();
  [GeneratedRegex(@"^\[(\d{2}:\d{2}:\d{2}|\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\]")]
  private static partial Regex DateTimeStampRegex();
  [GeneratedRegex(@"^::\s*\d+\s*-\s+.+")]
  private static partial Regex SectionHeaderNumberRegex();
  [GeneratedRegex(@"^::\s*[A-Z0-9_ ]+$")]
  private static partial Regex SectionHeaderUppercaseRegex();

  private static bool IsSectionTitle(string line) {
    string trimmed = line.Trim();

    if (!trimmed.StartsWith("::"))
      return false;

    if (SectionHeaderNumberRegex().IsMatch(trimmed))
      return true;

    if (SectionHeaderUppercaseRegex().IsMatch(trimmed))
      return true;

    return false;
  }


  private string BuildCollapsedPreview() {
    if (string.IsNullOrWhiteSpace(_fullPreviewText))
      return "";

    string[] lines = _fullPreviewText.Replace("\r\n","\n").Split('\n');
    List<string> output = [];

    bool skipping = false;

    foreach (string line in lines) {
      if (IsSectionTitle(line)) {
        string section = line.Trim();

        skipping = _collapsedSections.Contains(section);

        output.Add(line);

        if (skipping)
          output.Add("::     ... section repliée ...");

        continue;
      }

      if (!skipping)
        output.Add(line);
    }

    return string.Join(Environment.NewLine,output);
  }

  private static string GetRichText(
  RichTextBox richTextBox) {

    return new TextRange(
      richTextBox.Document.ContentStart,
      richTextBox.Document.ContentEnd)
      .Text;
  }

  private static void SetRichText(
    RichTextBox richTextBox,
    string text) {

    new TextRange(
      richTextBox.Document.ContentStart,
      richTextBox.Document.ContentEnd)
      .Text = text;
  }

  private void ApplySyntaxHighlighting() {

    RichTextBox textBox =
      CurrentPreviewTextBox;

    switch (_activePreviewDocument) {

      case PreviewDocumentType.AutoUnattend:

      case PreviewDocumentType.Unattend:

        _syntaxHighlighter.ApplyXml(
          textBox);

        break;


      case PreviewDocumentType.ProfileJson:

        _syntaxHighlighter.ApplyJson(
          textBox);

        break;


      default:

        _syntaxHighlighter.ApplyCmd(
          textBox);

        break;
    }
  }

  private void RefreshPreview() {
    _refreshCount++;
    Debug.WriteLine($"REFRESH #{_refreshCount} - Active={_activePreviewDocument}");
    try {
      _isUpdatingPreview = true;

      ApplyUiToProfile();

      string result = GeneratePreviewDocument(_activePreviewDocument);

      if (_activePreviewDocument == PreviewDocumentType.Diskprep) {
        _fullPreviewText = result;
        result = BuildCollapsedPreview();
      }

      RichTextBox textBox = CurrentPreviewTextBox;

      if (GetRichText(textBox) != result)
        SetRichText(textBox,result);

      ApplySyntaxHighlighting();

      //pnlLineNumbers.Invalidate();
      //pnlMiniMap.Invalidate();
    }
    catch (Exception ex) {
      string message =
        "ERREUR PREVIEW :" + Environment.NewLine +
        ex.Message + Environment.NewLine +
        Environment.NewLine +
        ex.StackTrace;

      SetRichText(CurrentPreviewTextBox,message);
    }
    finally {
      _isUpdatingPreview = false;
    }
  }



  private static void SetItemChecked(ListBox listBox,int index,bool isChecked) {
    if (index < 0 || index >= listBox.Items.Count) {
      return;
    }
    if (listBox.Items[index] is CheckBox checkBox) {
      checkBox.IsChecked = isChecked;
    }
  }
  private void LoadProfileToUi() {
    _livePreviewReady = false;

    cmbOsDisk.SelectedItem = _detectedDisks.FirstOrDefault(
        d => d.DiskNumber == _profile.Disk.OsDisk
    );

    cmbData1Disk.SelectedItem = _detectedDisks.FirstOrDefault(
        d => d.DiskNumber == (_profile.Disk.DataDisk ?? 1)
    );

    cmbData2Disk.SelectedItem = _detectedDisks.FirstOrDefault(
        d => d.DiskNumber == (_profile.Disk.Data2Disk ?? 1)
    );

    chkSeparateDataDisk.IsChecked =
        _profile.Disk.LayoutMode == DiskLayoutMode.SeparateDataDisk;

    chkCreateData1.IsChecked = _profile.Disk.CreateData1;
    chkCreateData2.IsChecked = _profile.Disk.CreateData2;

    numEfiSize.Value = _profile.Disk.EfiSizeMb;
    numMsrSize.Value = _profile.Disk.MsrSizeMb;
    numSystemBiosSize.Value = _profile.Disk.SystemSizeMb;
    numWindowsSize.Value = _profile.Disk.WindowsSizeMb;
    numRecoverySize.Value = _profile.Disk.RecoverySizeMb;

    numImageIndex.Value = _profile.Image.ImageIndex;

    cmbImageType.SelectedIndex = _profile.Image.ImageType switch {
      WindowsImageType.Wim => 1,
      WindowsImageType.Esd => 2,
      _ => 0
    };

    SelectComboValue(cmbUiLanguage,_profile.Unattend.UILanguage);
    SelectComboValue(cmbTimeZone,_profile.Unattend.TimeZone);

    txtProductKey.Text = _profile.Unattend.ProductKey;
    txtOrganization.Text = _profile.Unattend.Organization;
    txtOwner.Text = _profile.Unattend.Owner;
    txtComputerName.Text = _profile.Unattend.ComputerName;

    chkCreateLocalAccount.IsChecked = _profile.Unattend.CreateLocalAccount;
    txtLocalUserName.Text = _profile.Unattend.LocalUserName;
    txtAdminPassword.Password = _profile.Unattend.LocalUserPassword;
    SelectComboValue(cmbLocalUserGroup,_profile.Unattend.LocalUserGroup);

    chkEnableAutoLogon.IsChecked = _profile.Unattend.EnableAutoLogon;
    numAutoLogonCount.Value = _profile.Unattend.AutoLogonCount;

    chkCreateLocalAccount.IsChecked = _profile.Unattend.CreateLocalAccount;
    txtLocalUserName.Text = _profile.Unattend.LocalUserName;
    txtAdminPassword.Password = _profile.Unattend.LocalUserPassword;

    SelectComboValue(
        cmbLocalUserGroup,
        _profile.Unattend.LocalUserGroup
    );

    chkEnableAutoLogon.IsChecked = _profile.Unattend.EnableAutoLogon;
    numAutoLogonCount.Value = _profile.Unattend.AutoLogonCount;

    for (int i = 0;i < lstInputLocales.Items.Count;i++) {
      if (lstInputLocales.Items[i] is KeyboardLocaleOption option) {
        bool isChecked = _profile.Unattend.InputLocaleCodes.Contains(option.InputLocaleCode);
        SetItemChecked(lstInputLocales,i,isChecked);
      }
    }
    lstInputLocales.IsKeyboardFocusWithinChanged += (_,e) => {
      if (e.NewValue is false) {
        ConfigurationChanged(lstInputLocales,new RoutedEventArgs());
      }
    };

    txtPackageName.Text = _profile.Package.PackageName;
    txtPackageVersion.Text = _profile.Package.Version;
    txtPackageAuthor.Text = _profile.Package.Author;
    txtOutputDirectory.Text = _profile.Package.OutputDirectory;

    chkIncludeDrivers.IsChecked = _profile.Package.IncludeDrivers;
    chkIncludeApplications.IsChecked = _profile.Package.IncludeApplications;
    chkIncludeScripts.IsChecked = _profile.Package.IncludeScripts;
    chkIncludeWinPE.IsChecked = _profile.Package.IncludeWinPE;

    txtDriversSourcePath.Text = _profile.Package.DriversSourcePath;
    txtApplicationsSourcePath.Text = _profile.Package.ApplicationsSourcePath;
    //txtScriptsSourcePath.Text = _profile.Package.ScriptsSourcePath;
    //txtWinPESourcePath.Text = _profile.Package.WinPESourcePath;

    chkIncludeSetupScripts.IsChecked = _profile.Package.IncludeSetupScripts;
    chkIncludeSetupConfig.IsChecked = _profile.Package.IncludeSetupConfig;

    txtSetupScriptsSourcePath.Text = _profile.Package.SetupScriptsSourcePath;
    txtSetupConfigSourcePath.Text = _profile.Package.SetupConfigSourcePath;

    txtWindowsIsoPath.Text = _profile.WindowsMedia.WindowsIsoPath;
    txtMediaWorkingDirectory.Text = _profile.WindowsMedia.MediaFolder;
    chkExtractWindowsIso.IsChecked = _profile.WindowsMedia.ExtractWindowsIso;
    chkInjectAutounattend.IsChecked = _profile.WindowsMedia.InjectAutounattend;
    chkInjectDeployFolder.IsChecked = _profile.WindowsMedia.InjectDeployFolder;
    chkPrepareUsbMedia.IsChecked = _profile.WindowsMedia.PrepareUsbMedia;
    cmbUsbDriveLetter.Text = _profile.WindowsMedia.UsbDriveLetter;

    chkBuildIso.IsChecked = _profile.WindowsMedia.BuildIso;
    txtFinalIsoPath.Text = _profile.WindowsMedia.IsoOutputPath;

    chkRunDetachUsb.IsChecked = _profile.Orchestration.RunDetachUsb;
    chkRunReorgVolumes.IsChecked = _profile.Orchestration.RunReorgVolumes;
    chkRunWifi.IsChecked = _profile.Orchestration.RunWifi;
    chkRunDrivers.IsChecked = _profile.Orchestration.RunDrivers;
    chkRunWindowsUpdateDrivers.IsChecked = _profile.Orchestration.RunWindowsUpdateDrivers;
    chkRunSoftwares.IsChecked = _profile.Orchestration.RunSoftwares;
    chkRunM365.IsChecked = _profile.Orchestration.RunMicrosoft365;
    chkRunPostInstall.IsChecked = _profile.Orchestration.RunPostInstall;
    chkRunCleanup.IsChecked = _profile.Orchestration.RunCleanup;

    UpdateUiState();

    _livePreviewReady = true;

    ValidateConfiguration();
    RefreshPreview();
    UpdateStatusBar();
  }

  private void ResetValidationColors() {
    cmbData1Disk.Foreground = Brushes.White;
    cmbData2Disk.Foreground = Brushes.White;

    lblData1Disk.Foreground = Brushes.White;
    lblData2Disk.Foreground = Brushes.White;
    lblWindowsSize.Foreground = Brushes.White;
    lblStatusProfile.Foreground = Brushes.White;
  }

  private static int GetSelectedDiskNumber(ComboBox comboBox) {
    return comboBox.SelectedItem is PhysicalDiskInfo disk
        ? disk.DiskNumber
        : -1;
  }

  private void MarkInvalid(Control control,Label label,string message) {
    _hasValidationError = true;

    control.Foreground = Brushes.OrangeRed;
    label.Foreground = Brushes.OrangeRed;
    lblValidation.Foreground = Brushes.OrangeRed;
    lblValidation.Background = Brushes.Transparent;
    lblValidation.Content = message;
    control.ToolTip = message;
  }

  private void ValidateConfiguration() {
    _hasValidationError = false;
    ResetValidationColors();

    lblValidation.Content = "";

    int osDisk = GetSelectedDiskNumber(cmbOsDisk);
    int dataDisk = GetSelectedDiskNumber(cmbData1Disk);
    int data2Disk = GetSelectedDiskNumber(cmbData2Disk);

    if (chkSeparateDataDisk.IsChecked == true && dataDisk == osDisk) {
      MarkInvalid(
          cmbData1Disk,
          lblData1Disk,
          "ERROR : Data-1 utilise le même disque que l'OS."
      );
    }

    if (chkCreateData2.IsChecked == true && data2Disk == osDisk) {
      MarkInvalid(
          cmbData2Disk,
          lblData2Disk,
          "ERROR : Data-2 utilise le même disque que l'OS."
      );
    }

    if (chkSeparateDataDisk.IsChecked == true && chkCreateData2.IsChecked == true && dataDisk == data2Disk) {
      MarkInvalid(
          cmbData2Disk,
          lblData2Disk,
          "ERROR : Data-1 et Data-2 utilisent le même disque."
      );
    }

    if (numWindowsSize.Value < 40000) {
      MarkInvalid(
          numWindowsSize,
          lblWindowsSize,
          "WARNING : la partition Windows est inférieure à 40 Go."
      );
    }

    if (_hasValidationError) {
      lblStatusProfile.Text = "⚠ Configuration invalide";
      lblStatusProfile.Foreground = Brushes.OrangeRed;
    }
    else {
      lblStatusProfile.Text = string.IsNullOrWhiteSpace(_currentProfilePath)
          ? "Profil : non sauvegardé"
          : "Profil : " + Path.GetFileName(_currentProfilePath);

      lblStatusProfile.Foreground = Brushes.White;
    }
  }

  private void UpdateUiState() {
    bool showData1 = chkSeparateDataDisk.IsChecked == true;
    lblData1Disk.Visibility = showData1
        ? Visibility.Visible
        : Visibility.Hidden;

    cmbData1Disk.Visibility = showData1
        ? Visibility.Visible
        : Visibility.Hidden;

    bool showData2 = chkCreateData2.IsChecked == true;
    lblData2Disk.Visibility = showData2
        ? Visibility.Visible
        : Visibility.Hidden;

    cmbData2Disk.Visibility = showData2
        ? Visibility.Visible
        : Visibility.Hidden;

    cmbData1Disk.IsEnabled = chkSeparateDataDisk.IsChecked == true;
    cmbData2Disk.IsEnabled = chkCreateData2.IsChecked == true;

    txtLocalUserName.IsEnabled = chkCreateLocalAccount.IsChecked == true;
    txtAdminPassword.IsEnabled = chkCreateLocalAccount.IsChecked == true;
    cmbLocalUserGroup.IsEnabled = chkCreateLocalAccount.IsChecked == true;

    chkEnableAutoLogon.IsEnabled = chkCreateLocalAccount.IsChecked == true;
    numAutoLogonCount.IsEnabled = chkCreateLocalAccount.IsChecked == true && chkEnableAutoLogon.IsChecked == true;

    txtDriversSourcePath.IsEnabled = chkIncludeDrivers.IsChecked == true;
    btnBrowseDriversSourcePath.IsEnabled = chkIncludeDrivers.IsChecked == true;

    txtApplicationsSourcePath.IsEnabled = chkIncludeApplications.IsChecked == true;
    btnBrowseApplicationsSourcePath.IsEnabled = chkIncludeApplications.IsChecked == true;

    txtSetupScriptsSourcePath.IsEnabled = chkIncludeScripts.IsChecked == true;
    btnBrowseSetupScriptsSourcePath.IsEnabled = chkIncludeScripts.IsChecked == true;

    //txtWinPESourcePath.IsEnabled = chkIncludeWinPE.IsChecked == true;
    //btnBrowseWinPE.IsEnabled = chkIncludeWinPE.IsChecked == true;

    txtSetupScriptsSourcePath.IsEnabled = chkIncludeSetupScripts.IsChecked == true;
    btnBrowseSetupScriptsSourcePath.IsEnabled = chkIncludeSetupScripts.IsChecked == true;

    txtSetupConfigSourcePath.IsEnabled = chkIncludeSetupConfig.IsChecked == true;
    btnBrowseSetupConfigSourcePath.IsEnabled = chkIncludeSetupConfig.IsChecked == true;
  }

  private void UpdateStatusBar() {
    if (!_hasValidationError) {
      lblStatusProfile.Text = string.IsNullOrWhiteSpace(_currentProfilePath)
          ? "Profil : non sauvegardé"
          : "Profil : " + Path.GetFileName(_currentProfilePath);

      lblStatusProfile.Foreground = System.Windows.Media.Brushes.White;
    }

    lblStatusDisks.Text = $"Disques : {_detectedDisks.Count} détecté(s)";
    lblStatusImage.Text = $"Image : {_profile.Image.ImageType} / Index {_profile.Image.ImageIndex}";
  }

  private void DarkTheme() {

    ThemeManager.SetTheme(
      ThemeMode.IsChecked
        ? AppTheme.Dark
        : AppTheme.Light);

    lblValidation.Foreground = System.Windows.Media.Brushes.Red;
    lblOrchestrationPending.Foreground = System.Windows.Media.Brushes.Orange;
  }

  private static void BrowseFolderInto(TextBox target) {
    OpenFolderDialog dialog = new();

    if (!string.IsNullOrWhiteSpace(target.Text) && Directory.Exists(target.Text))
      dialog.InitialDirectory = target.Text;

    if (dialog.ShowDialog() == true)
      target.Text = dialog.FolderName;
  }

  //private BuildPipelineService CreatePipelineService() {
  //  BuildPipelineService service = new();

  //  service.ProgressChanged += (value,message) => {
  //    if (InvokeRequired) {
  //      BeginInvoke(new Action(() => {
  //        UpdateBuildProgress(value,message);
  //      }));
  //    }
  //    else {
  //      UpdateBuildProgress(value,message);
  //    }
  //  };

  //  return service;
  //}

  private async Task BuildPackage() {
    //ApplyUiToProfile();

    progressBuild.Value = 0;
    lblBuildProgress.Content = "Démarrage...";

    //BuildPipelineService service = CreatePipelineService();

    PipelineResult result = await Task.Run(() =>
        BuildPipelineService.BuildPackage(_profile)
    );

    //AppendPipelineLogs(result);

    lblBuildProgress.Content = result.Success ? "Terminé" : "Erreur";

    MessageBox.Show(
        result.Message,
        "Build Package",
        MessageBoxButton.OK,
        result.Success ? MessageBoxImage.Information : MessageBoxImage.Error
    );
  }

  private bool TryGetSelectedPreviewEditor(out RichTextBox editor) {
    editor = null!;

    if (txtDiskprepPreview.SelectedItem is not TabItem selectedTab)
      return false;

    string? key = selectedTab.Header?.ToString();

    if (string.IsNullOrWhiteSpace(key))
      return false;

    return _previewEditors.TryGetValue(key,out editor!);
  }

  private static string GetEditorText(RichTextBox editor) {
    TextRange range =
        new(editor.Document.ContentStart,
            editor.Document.ContentEnd);

    string text = range.Text;

    // Le FlowDocument ajoute généralement un retour de fin de paragraphe
    if (text.EndsWith("\r\n"))
      text = text[..^2];

    return text;
  }

  private void mnuPrintSelectedView_Click(object sender,RoutedEventArgs e) {
    bool flowControl = PrintSelectedView();
    if (!flowControl) {
      return;
    }
  }

  private bool PrintSelectedView() {
    if (!TryGetSelectedPreviewEditor(out RichTextBox textBox)) {
      MessageBox.Show(
          "Aucune vue sélectionnée.",
          "Impression",
          MessageBoxButton.OK,
          MessageBoxImage.Warning);
      return false;
    }
    string text = GetEditorText(textBox);
    if (string.IsNullOrWhiteSpace(text)) {
      MessageBox.Show(
          "Aucun contenu à imprimer.",
          "Impression",
          MessageBoxButton.OK,
          MessageBoxImage.Warning);

      return false;
    }

    PrintDialog dialog = new();

    if (dialog.ShowDialog() != true)
      return false;

    string documentName =
        (txtDiskprepPreview.SelectedItem as TabItem)?
            .Header?
            .ToString()
        ?? "preview";

    DocumentPaginator paginator =
        ((IDocumentPaginatorSource)textBox.Document)
            .DocumentPaginator;

    paginator.PageSize =
        new Size(
            dialog.PrintableAreaWidth,
            dialog.PrintableAreaHeight);

    dialog.PrintDocument(
        paginator,
        documentName);
    return true;
  }

  private void btnBrowseOutputDirectory_Click(object sender,RoutedEventArgs e) {
    BrowseFolderInto(txtOutputDirectory);
  }

  private void btnBrowseApplicationsSourcePath_Click(object sender,RoutedEventArgs e) {
    BrowseFolderInto(txtApplicationsSourcePath);
  }

  private void btnBrowseSetupScriptsSourcePath_Click(object sender,RoutedEventArgs e) {
    BrowseFolderInto(txtSetupScriptsSourcePath);
  }

  private void btnBrowseDriversSourcePath_Click(object sender,RoutedEventArgs e) {
    BrowseFolderInto(txtDriversSourcePath);
  }

  private void btnBrowseWindowsIsoPath_Click(object sender,RoutedEventArgs e) {
    BrowseFolderInto(txtWindowsIsoPath);
  }

  private void btnBrowseMediaWorkingDirectory_Click(object sender,RoutedEventArgs e) {
    BrowseFolderInto(txtMediaWorkingDirectory);
  }

  private void btnBuildWindowsMedia_Click(object sender,RoutedEventArgs e) {

  }

  private void btnOpenMediaFolder_Click(object sender,RoutedEventArgs e) {

  }

  private void btnApply_Click(object sender,RoutedEventArgs e) {

  }

  private void btnBuildIso_Click(object sender,RoutedEventArgs e) {

  }

  private void menuSaveProfile_Click(object? sender,RoutedEventArgs e) {
    //ApplyUiToProfile();

    SaveFileDialog dialog = new() {
      Filter = "Deploy Profile (*.deploy.json)|*.deploy.json",
      FileName = "default.deploy.json"
    };

    if (dialog.ShowDialog() != true)
      return;

    ProfileSerializer.Save(dialog.FileName,_profile);

    _currentProfilePath = dialog.FileName;

    UpdateStatusBar();
  }

  private void menuOpenProfile_Click(object? sender,RoutedEventArgs e) {
    OpenFileDialog dialog = new() {
      Filter = "Deploy Profile (*.deploy.json)|*.deploy.json"
    };

    if (dialog.ShowDialog(this) != true)
      return;

    _profile = ProfileSerializer.Load(dialog.FileName);
    _currentProfilePath = dialog.FileName;

    //LoadProfileToUi();
  }

  private void menuNewProfile_Click(object? sender,RoutedEventArgs e) {
    _profile = new DeploymentProfile();
    _currentProfilePath = "";
    //LoadProfileToUi();
  }

  private void menuExit_Click(object? sender,RoutedEventArgs e) {
    if (_orchestrationPendingChanges)
      Close();
  }

  private void menuEditSelectedView_Click(object sender,RoutedEventArgs e) {
    bool flowControl = PrintSelectedView();
    if (!flowControl) {
      return;
    }
  }

  private async void mnuBuildPackage_Click(object sender,RoutedEventArgs e) {
    await BuildPackage();
  }

  private void mnuBuildWindowsMedia_Click(object sender,RoutedEventArgs e) {

  }

  private void mnuBuildAll_Click(object sender,RoutedEventArgs e) {

  }

  private void mnuPrepareUsb_Click(object sender,RoutedEventArgs e) {

  }

  private void mnuOpenPackageFolder_Click(object sender,RoutedEventArgs e) {

  }

  private void mnuOpenBuildFolder_Click(object sender,RoutedEventArgs e) {

  }

  private void mnuEditWithNotepadPlusPlus_Click(object sender,RoutedEventArgs e) {

  }

  private void menuPrintSelectedView_Click(object sender,RoutedEventArgs e) {

  }

  private void menuSaveProfileAs_Click(object sender,RoutedEventArgs e) {

  }

  private static void OpenFileInNotepadPlusPlus(string path) {
    Process.Start(new ProcessStartInfo {
      FileName = @"C:\Program Files\Notepad++\notepad++.exe",
      Arguments = $"\"{path}\"",
      UseShellExecute = true
    });
  }

  private static void OpenTextInNotepadPlusPlus(string content,string fileName) {
    if (string.IsNullOrWhiteSpace(content)) {
      MessageBox.Show("Contenu vide.","Notepad++",
          MessageBoxButton.OK,MessageBoxImage.Warning);
      return;
    }

    string tempPath = Path.Combine(Path.GetTempPath(),fileName);

    File.WriteAllText(tempPath,content,EncodingHelper.Utf8NoBom);

    Process.Start(new ProcessStartInfo {
      FileName = @"C:\Program Files\Notepad++\notepad++.exe",
      Arguments = $"\"{tempPath}\"",
      UseShellExecute = true
    });
  }

  private void mnuEditFileWithNotepadPlusPlus_Click(object sender,RoutedEventArgs e) {
    if (sender is not MenuItem menuItem || menuItem.Tag is not string document) {
      return;
    }
    switch (document) {
      case "diskprep.cmd":
        OpenTextInNotepadPlusPlus(GetRichText(previewDiskPrep.Editor),"diskprep.cmd");
        break;

      case "SetupComplete.cmd":
        OpenTextInNotepadPlusPlus(GetRichText(previewSetupComplete.Editor),"SetupComplete.cmd");
        break;

      case "orchestrator_resume.cmd":
        OpenTextInNotepadPlusPlus(GetRichText(previewOrchestrator_resume.Editor),"orchestrator_resume.cmd");
        break;

      case "autounattend.xml":
        OpenTextInNotepadPlusPlus(GetRichText(previewAutoUnattend.Editor),"autounattend.xml");
        break;

      case "unattend.xml":
        OpenTextInNotepadPlusPlus(GetRichText(previewUnattend.Editor),"unattend.xml");
        break;


      case "BuildReport":
        OpenTextInNotepadPlusPlus(GetRichText(previewprofileBuildReport.Editor),"BuildReport.txt");
        break;

      case "BuildLog":
        OpenTextInNotepadPlusPlus(GetRichText(previewBuildLog.Editor),"BuildLog.txt");
        break;

      case "CurrentProfile":
        if (string.IsNullOrWhiteSpace(_currentProfilePath) || !File.Exists(_currentProfilePath)) {
          MessageBox.Show("Aucun fichier profil JSON chargé.");
          return;
        }
        OpenTextInNotepadPlusPlus(File.ReadAllText(_currentProfilePath),"profile.deploy.json");
        break;
    }
  }
  private void mnuOemCommands_Click(object sender,RoutedEventArgs e) {

  }

  private void mnuSynchronousCommands_Click(object sender,RoutedEventArgs e) {

  }

  private void mnuAbout_Click(object? sender,RoutedEventArgs e) {
    HelpHelper.mnuAbout(this,_profile);
  }

  private void MnuLicense_Click(object sender,RoutedEventArgs e) {
    LicenseHelper.AfficherLicence(this,_licenseService,_profile);
  }

  private void MnuImportNewLicense_Click(object sender,RoutedEventArgs e) {
    LicenseHelper.ImporterLicence(this,_licenseService);
  }

  private async void MnuCheckForUpdate_Click(object sender,RoutedEventArgs e) {
    await HelpHelper.mnuCheckForUpdates(this,_profile);
  }

  private void btnBuildAll_Click(object sender,RoutedEventArgs e) {

  }

  private void btnOpenBuildAllPackages_Click(object sender,RoutedEventArgs e) {

  }

  private void btnBuildPackage_Click(object sender,RoutedEventArgs e) {

  }

  private void btnOpenPackageFolder_Click(object sender,RoutedEventArgs e) {

  }

  private void btnPrepareUSB_Click(object sender,RoutedEventArgs e) {

  }

  private void btnPauseResume_Click(object sender,RoutedEventArgs e) {

  }

  private void btnCancelBuild_Click(object sender,RoutedEventArgs e) {

  }

  private void btnPrintSelectedView_Click(object sender,RoutedEventArgs e) {
    bool flowControl = PrintSelectedView();
    if (!flowControl) {
      return;
    }
  }

  private void btnCloseSearch_Click(object sender,RoutedEventArgs e) {

  }

  private void btnFindNext_Click(object sender,RoutedEventArgs e) {

  }

  private void btnBrowseSetupConfigSourcePath_Click(object sender,RoutedEventArgs e) {

  }
}